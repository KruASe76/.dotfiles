import os
import subprocess
from gi.repository import Nautilus, GObject, Gio

class SnoopMenuProvider(GObject.GObject, Nautilus.MenuProvider):
    def __init__(self):
        pass

    def __open_snoop(self, file):
        try:
            outp = subprocess.check_output(["which", "snoop"])
            os.system(f"snoop {file.get_uri()} &")
        except Exception as _ex:
            print("cannot find snoop")
            # fallback to flatpak
            os.system(f"flatpak run de.philippun1.Snoop  {file.get_uri()} &")

    def menu_activate_cb(self, menu, file):
        self.__open_snoop(file)

    def menu_background_activate_cb(self, menu, file):
        self.__open_snoop(file)

    def __create_sub_menu(self, file):
        if file.get_file_type()== Gio.FileType.DIRECTORY:
            item = Nautilus.MenuItem(name='SnoopMenuProvider::Search',
                                         label='Search here...',
                                         tip='',
                                         icon='search-symbolic')
            item.connect('activate', self.menu_activate_cb, file)

            return item

    def get_file_items(self, files):
        if len(files) == 1:
            item = self.__create_sub_menu(files[0])

            return item,

    def get_background_items(self, file):
        item = self.__create_sub_menu(file)

        return item,
